STEPS TO RUN ->

1. open terminal
2. run ->     make all
3. run ->     use "loader.sml";
4. run ->     compile(fileNameInQuotes);
5. Please run 3rd step every time after 4th because lexer stores the previous result in buffer which might lead to weird output ;-(
